******Data Structure Assignment******
1. Linked List
2. Stack
3. Queue
4. Priority Queue
5. Hash Table
6. N-child Tree
0 to exit